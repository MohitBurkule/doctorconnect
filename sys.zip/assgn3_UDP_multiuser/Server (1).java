import java.net.*;
import java.io.*;
import java.nio.charset.*;
public class Server {
	public static void main(String[] args)throws IOException
	{	String str2;
		int portno;
		byte[] buffer1=new byte[100];
		byte[] buffer2=new byte[100];
		
		DatagramSocket ds=new DatagramSocket(6005);
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		InetAddress In=InetAddress.getLocalHost();
		while(true)
		{DatagramPacket packet=new DatagramPacket(buffer1,buffer1.length);
		ds.receive(packet);
		buffer1=packet.getData();
		String str1=new String(buffer1,StandardCharsets.UTF_8);
		System.out.print("received data :"+str1);
		
		System.out.println("reply from server :");
		str2=br.readLine();
		buffer2=str1.getBytes();
		portno=packet.getPort();
		DatagramPacket packet1=new DatagramPacket(buffer2,buffer2.length,In,portno);//3555=>port no for server
		ds.send(packet1);
		}
	}
}
