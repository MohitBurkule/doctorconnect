import java.net.*;
import java.nio.charset.StandardCharsets;
import java.io.*;
public class Client1 {
	public static void main(String[] args)throws IOException
	{	String str;
		byte[] buffer=new byte[100];
		byte[] buffer1=new byte[100];
		//int portno;
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		BufferedReader br1=new BufferedReader(new InputStreamReader(System.in));

		//System.out.print("enter port no :");
		//portno=br1.read();
		DatagramSocket ds1=new DatagramSocket(3400);//2555=>port no for client	
		InetAddress In=InetAddress.getLocalHost();
		
		System.out.println("enter data :");
		str=br.readLine();
		buffer=str.getBytes();
		DatagramPacket packet=new DatagramPacket(buffer,buffer.length,In,6005);//3555=>port no for server
		ds1.send(packet);
		
		DatagramPacket packet2=new DatagramPacket(buffer1,buffer1.length);
		ds1.receive(packet2);
		buffer1=packet2.getData();
		String str1=new String(buffer1,StandardCharsets.UTF_8);
		System.out.print("received data :"+str1);
		
		
	}
}
