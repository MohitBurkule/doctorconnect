import java.net.*;
import java.io.*;
public class ClientSelective {
	public static void main(String[] args)throws IOException
	{	int v[]=new int[10];
		Socket s=new Socket("localhost",5580);
		DataInputStream din=new DataInputStream(s.getInputStream());
		DataOutputStream dout=new DataOutputStream(s.getOutputStream());
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		int p=din.read();
		System.out.println("length of frame : "+p);
		System.out.println("data :");
		for(int i=0;i<9;i++)
		{
			v[i]=din.read();
			System.out.print(" "+v[i]);
		}
		
		v[5]=-1;//inserting error
		
		System.out.println("\nreceived frame  after inserting error is :");
		for(int i=0;i<9;i++)
		{
			System.out.print(" "+v[i]);
		}
		
		for(int i=0;i<9;i++)
		{
			if(v[i]==-1)
				dout.write(i);
		}
		
		int q=din.read();
		v[5]=q;
		System.out.println("\ncorrect frame is :");
		for(int i=0;i<9;i++)
		{
			System.out.print(" "+v[i]);
		}
		br.close();
		dout.close();
		din.close();
		s.close();
	}
}