import java.net.*;
import java.io.*;
public class ServerSelective {
	public static void main(String[] args)throws IOException
	{		
			int a[]={10,20,30,40,50,60,70,80,90};
			ServerSocket ss=new ServerSocket(5580);//port no same as client
			Socket s1 = ss.accept();//accepting request from client
			DataInputStream din=new DataInputStream(s1.getInputStream());//converts bytes to any type
			DataOutputStream dout=new DataOutputStream(s1.getOutputStream());
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			
			int y=a.length;
			dout.write(y);
			for(int i=0;i<9;i++)
			{
				dout.write(a[i]);
				
			}
			int j=din.read();
			dout.write(a[j]);
			
			br.close();
			dout.close();
			din.close();
			s1.close();
			ss.close();
		
	}
}