/* A simple server in the internet domain using TCP
   The port number is passed as an argument */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h> //contains definitions of a number of data types used in system calls
#include <sys/socket.h> //includes a number of definitions of structures needed for sockets
#include <netinet/in.h> //contains constants and structures needed for internet domain addresses.

void error(const char *msg) //This function is called when a system call fails
{
    perror(msg);
    exit(1);
}

int main(int argc, char *argv[])
{
     int sockfd, newsockfd, portno; //file descriptors,store the values returned by the socket system call and the accept system call
     socklen_t clilen;
     char buffer[255];
     struct sockaddr_in serv_addr, cli_addr; //structure containing an internet address
     int n;
     if (argc < 2) {
         fprintf(stderr,"ERROR, no port provided\n");
         exit(1);
     }
     sockfd = socket(AF_INET, SOCK_STREAM, 0); //address domain,type of socket,protocol
     if (sockfd < 0) 
        error("ERROR opening socket");
     bzero((char *) &serv_addr, sizeof(serv_addr));  //sets all values in a buffer to zero
     portno = atoi(argv[1]); //convert a string of digits to an integer
     serv_addr.sin_family = AF_INET; //contains a code for the address family
     serv_addr.sin_addr.s_addr = INADDR_ANY; //P address of the machine on which the server is running
     serv_addr.sin_port = htons(portno); //converts a port number in host byte order to a port number in network byte order. 
     if (bind(sockfd, (struct sockaddr *) &serv_addr,sizeof(serv_addr)) < 0) //binds a socket to an address
              error("ERROR on binding");
     listen(sockfd,5);
     clilen = sizeof(cli_addr);
     newsockfd = accept(sockfd,(struct sockaddr *) &cli_addr, &clilen);
     if (newsockfd < 0) 
          error("ERROR on accept");
     while(1)
     {
           bzero(buffer,256);
           n = read(newsockfd,buffer,255); //will read either the total number of characters in the socket or 255, whichever is less
           if (n < 0) 
		error("ERROR reading from socket");
          printf("Client: %s\n",buffer);
          bzero(buffer,256);
          fgets(buffer,255,stdin);
          n = write(newsockfd,buffer,strlen(buffer));
           if (n < 0) 
		error("ERROR writing to socket");
           int i=strncmp("Bye" , buffer, 3);
           if(i == 0)
               break;
     }
     close(newsockfd);
     close(sockfd);
     return 0; 
}
