//============================================================================
// Name        : assg4.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main() {
	int temp[20],f[20],fs,g[10],gs,rs,j,k;


	//sender
	cout<<"enter size of dataword :";
	cin>>fs;

	cout<<"entr dataword :";
	for(int i=0;i<fs;i++)
		cin>>f[i];

	cout<<"enter divisor size :";
	cin>>gs;

	cout<<"enter divisor :";
	for(int i=0;i<gs;i++)
		cin>>g[i];

	cout<<"\ndataword is :";
	for(int i=0;i<fs;i++)
		cout<<f[i];

	cout<<"\ndivisor is :";
		for(int i=0;i<gs;i++)
			cout<<g[i];

	rs=gs-1;	//no of zeros to append at the end of dataword=size of divisor-1

	for(int i=fs;i<fs+rs;i++)
		f[i]=0;			//dataword appended with zeros(no=divisor-1)


	for(int i=0;i<fs+rs;i++)	//size of codeword=fs+rs
		temp[i]=f[i];

	for(int i=0;i<fs;i++)	//to find remainder
	{
		j=0;
		k=i;
		if(temp[k]>=g[j])
		{
			for(j=0,k=i;j<gs;j++,k++)
				temp[k]=temp[k]^g[j];
		}
	}

	int remainder[rs];

	for(int i=0;i<rs;i++)
		remainder[i]=0;

	cout<<"\nremainder at sender side is :";
	for(int i=0;i<rs;i++)
	{	remainder[i]=temp[fs+i];		//last "rs" no of bits are taken into remainder
		cout<<remainder[i];
	}

	//receiver
	for(int i=fs;i<fs+rs;i++)
			f[i]=temp[i];		//codeword is appended with remainder

	cout<<"\ncodeword at receiver :";
		for(int i=0;i<fs+rs;i++)
			cout<<f[i];

	cout<<"\nenter codeword at receiver :";
	for(int i=0;i<fs+rs;i++)
		cin>>f[i];				//enter received codeword

	for(int i=0;i<fs+rs;i++)
		temp[i]=f[i];

	for(int i=0;i<fs;i++)		//finding remainder for received codeword
	{
		j=0;
		k=i;
		if(temp[k]>=g[j])
		{
			for(j=0,k=i;j<gs;j++,k++)
				temp[k]=temp[k]^g[j];
		}
	}


	cout<<"\nremainder at receiver side is :";
	for(int i=fs;i<fs+rs;i++)
	{	remainder[i]=temp[i];
		cout<<remainder[i];
	}

	int flag=0;
	for(int i=fs;i<fs+rs;i++)
	{
		if(remainder[i]==1)
		{	flag=1;
			break;
		}
	}
	if(flag==1)		//if remainder!=0 => error
		cout<<"\n\nerror!!";
	else
		cout<<"\n\nno error!!";

	return 0;
}

/*----OUTPUT------
enter size of dataword :4
entr dataword :1
0
0
1
enter divisor size :4
enter divisor :1
0
1
1

dataword is :1001
divisor is :1011
remainder at sender side is :110
codeword at receiver :1001110
enter codeword at receiver :1
0
0
1
0
1
0

remainder at receiver side is :100

error!!
*/

