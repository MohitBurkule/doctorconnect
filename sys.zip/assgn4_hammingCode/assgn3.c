/*
 ============================================================================
 Name        : assgn3.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

int main(void) {

	int data[7],datarec[7],p,p1,p2,p4,i;

	for(i=0;i<7;i++)
	{
		data[i]=datarec[i]=0;
	}

	printf("\nenter 4 bit dataword :");
	scanf("%d",&data[0]);
	scanf("%d",&data[1]);
	scanf("%d",&data[2]);
	scanf("%d",&data[4]);

	data[6]=data[4]^data[2]^data[0];
	data[5]=data[4]^data[1]^data[0];
	data[3]=data[2]^data[1]^data[0];

	printf("\ncodeword is : ");

	for(i=0;i<7;i++)
	{
		printf("%d",data[i]);
	}

	printf("\nenter 7 bit received codeword : ");
	for(i=0;i<7;i++)
		scanf("%d",&datarec[i]);

	p1=datarec[6]^datarec[4]^datarec[2]^datarec[0];
	p2=datarec[5]^datarec[4]^datarec[1]^datarec[0];
	p4=datarec[3]^datarec[2]^datarec[1]^datarec[0];

	p=p4*4+p2*2+p1;

	if(p==0)
	{
		printf("\nno error in received codeword!!");

	}
	else
	{
		printf("\nerror in received codeword!!");

		printf("\nreceived codeword is : ");

		for(i=0;i<7;i++)
			printf("%d",datarec[i]);

		printf("\nerror is present at bit no : %d",(7-p+1));
		if(datarec[7-p]==0)
			datarec[7-p]=1;
		else
			datarec[7-p]=0;

	}

	printf("\ncorrect codeword is : ");

	for(i=0;i<7;i++)
		printf("%d",datarec[i]);

}

/*----OUTPUT-----
 *
enter 4 bit dataword :1
0
1
1

codeword is : 1010101
enter 7 bit received codeword : 1
0
1
1
1
0
1

error in received codeword!!
received codeword is : 1011101
error is present at bit no : 4
correct codeword is : 1010101
*/

 */
