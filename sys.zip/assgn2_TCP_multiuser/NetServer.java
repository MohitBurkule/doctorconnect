// echo server

import java.io.*;
import java.net.*;


public class NetServer
{
  public static void main(String args[]) throws IOException
  {
    ServerSocket ss2=new ServerSocket(4445);
    System.out.println("Server Listening......");
  
    while(true)
    {
       	    Socket s= ss2.accept();
            System.out.println("connection Established");
            ServerThread st=new ServerThread(s);
            st.start();

      }
  }
}

class ServerThread extends Thread
{  
    String line=null;
    BufferedReader br = null;
    DataOutputStream dos=null;
    DataInputStream dis=null;
    Socket s=null;
   
    public ServerThread(Socket s)
	{
        this.s=s;  //invoke or initiate current class constructor
  	 }

    public void run()
    {
	try{
   	    br= new BufferedReader(new InputStreamReader(System.in));
    	    dos=new DataOutputStream(s.getOutputStream());
            dis=new DataInputStream(s.getInputStream());

   	
	   line="";
     	   while(!line.equals("stop"))
	   {
       		line=dis.readUTF();  
		System.out.println("client says: "+line); 
		dos.flush();  
	    }   
   	}
	catch(IOException ie){
        System.out.println("Socket Close Error");
		}


		
finally{ try{
   br.close(); 
  dos.close();
  dis.close();
  s.close();
}
  catch(IOException ie){
        System.out.println("Socket Close Error");
}}
}
}
