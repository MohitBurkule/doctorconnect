// A simple Client Server Protocol .. Client for Echo Server


import java.io.*;
import java.net.*;

public class NetClient {

public static void main(String args[]) throws IOException
{
    InetAddress address=InetAddress.getLocalHost(); //this class represents an IP address using the methods getLocalHost,getByName,or getAllByName to create a new InetAddress instance
    Socket s1=null;
    String line=null;
    BufferedReader br=null;
    BufferedReader br1=null;
    DataOutputStream dos=null;

        s1=new Socket("localhost", 4445); 
        br= new BufferedReader(new InputStreamReader(System.in));
        br1=new BufferedReader(new InputStreamReader(s1.getInputStream()));
        dos= new DataOutputStream(s1.getOutputStream());
 

    System.out.println("Client Address : "+address);
    System.out.println("Enter Data to echo Server ( Enter QUIT to end):");

    String response="";
      try{
        line=br.readLine(); 
        while(!line.equals("stop"))
	{
	       dos.writeUTF(line);  
		dos.flush(); 
		System.out.println("Enter Data to echo Server ( Enter QUIT to end):");
               line=br.readLine();
        }
	}

 catch(IOException ie){
        System.out.println("Socket Close Error"); }
 
    finally{ try{

        br1.close();
	dos.close();
	br.close();
	s1.close();
        System.out.println("Connection Cldosed");
		}
 	catch(IOException ie){
        System.out.println("Socket Close Error"); }

    }

}
}
