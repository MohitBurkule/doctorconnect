import java.io.*;
import java.net.*;
import java.util.*;

public class GoBackN_client {
	public static void main(String args[]) throws Exception
	{
		try
		{
			int c,ch,j,i,check = 0;
			Socket s= new Socket("localhost",1050);
			BufferedInputStream in =new BufferedInputStream(s.getInputStream());
			DataOutputStream out =new DataOutputStream(s.getOutputStream());
			Scanner sc=new Scanner(System.in);
			
			System.out.println("Enter no. of frames to send : ");
			c=sc.nextInt();
			out.write(c);
			out.flush();
			System.out.println("0: Error free transfer \n1: With Error transfer \n Enter choice : ");
			ch=sc.nextInt();
			out.write(ch);
			out.flush();
			
			if(ch ==0)
			{
				System.out.println("Receiving frame ");
				for(j=0;j<c;j++)
				{
					i=in.read();				
					System.out.println("Receiving frame "+i);
					System.out.println("Sending acknowledgement for frame "+i);
					out.write(i);
					out.flush();
				}			
			}
			else
			{
				for(j=0;j<c;j++)
				{
					i=in.read();
					if(i==check)
					{
						System.out.println("Received frame "+i);
						System.out.println("Sending acknowledgement for frame "+i);
						out.write(i);
						++check;
					}
					else
					{
						--j;
						System.out.println("Discarded frame "+i);
						System.out.println("Sending negative acknowledgement");
						out.write(-1);
						
					}
					out.flush();
				}
				
				
				
				
			}
		} 
		catch (Exception e){}
	}
}
