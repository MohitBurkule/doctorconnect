import java.io.*;
import java.net.*;
import java.util.Scanner;


public class GoBackN_server {
	public static void main(String args[]) throws Exception
	{
		try
		{
			int p,pc,i,a;
			
			ServerSocket ss= new ServerSocket(1050);
			Socket s=ss.accept();
			BufferedInputStream in =new BufferedInputStream(s.getInputStream());
			DataOutputStream out =new DataOutputStream(s.getOutputStream());
			Scanner sc=new Scanner(System.in);
			
			p=in.read();		//no of frames
			pc=in.read();
			Boolean[] f=new Boolean[p];
			if(pc==0)
			{
				for(i=0;i<p;i++)
				{
					System.out.println("Sending frame "+i);
					out.write(i);
					out.flush();
					System.out.println("Waiting for acknowledgement...");
					try 
					{
						Thread.sleep(5000);
					}	
					catch(Exception e){}
					a=in.read();
					System.out.println("Acknowledgement received for frame "+a);
					
				}
			}
			else
			{
				for(i=0;i<p;i++)
				{
					if(i==2)
					{
						System.out.println("Sending frame "+i);
					}
					else
					{
						System.out.println("Sending frame "+i);
						out.write(i);
						out.flush();
						System.out.println("Waiting for acknowledgement...");
						try
						{
							Thread.sleep(2000);
						}
						catch(Exception e){}
						a=in.read();
						if(a!=255)
						{
							System.out.println("Acknowledgement received for frame "+a);
							f[i]=true;
						}
					}
				}
				for(i=0;i<p;i++)
				{
					if(f[i]==false)
					{
						System.out.println("Resending frame "+i);
						out.write(i);
						out.flush();
						System.out.println("Waiting for acknowledgement...");
						try
						{
							Thread.sleep(2000);
						}
						catch(Exception e){}
						int b=in.read();
						System.out.println("Acknowledgement received for frame "+b);
						f[i]=true;
					}
					break;
				}
			}
		}
		catch (Exception e){}
	}
		
}


