import java.net.*;
import java.io.*;
public class Client {
	public static void main(String[] args)throws IOException
	{	String str1,str2;
		Socket s=new Socket("localhost",5580);
		DataInputStream din=new DataInputStream(s.getInputStream());
		DataOutputStream dout=new DataOutputStream(s.getOutputStream());
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		do
		{
			System.out.println("enter data :");
			str1=br.readLine();
			dout.writeUTF(str1);
			str2=din.readUTF();
			System.out.println("server says :"+str2);
			dout.flush();
			
		}while(!str1.equals("stop"));
		br.close();
		dout.close();
		din.close();
		s.close();
	}
}
