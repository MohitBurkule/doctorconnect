import java.net.*;
import java.io.*;
public class Socket1 {
	public static void main(String[] args)throws IOException
	{		String str1,str2;
			ServerSocket ss=new ServerSocket(5580);//port no same as client
			Socket s1 = ss.accept();//accepting request from client
			DataInputStream din=new DataInputStream(s1.getInputStream());//converts bytes to any type
			DataOutputStream dout=new DataOutputStream(s1.getOutputStream());
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			
			do
			{	str2=din.readUTF();//
				System.out.println("client says :"+str2);
				
				System.out.println("enter response : ");
				str1=br.readLine();
				dout.writeUTF(str1);
				dout.flush();
			}while(!str1.equals("stop") && !str2.equals("stop"));
			br.close();
			dout.close();
			din.close();
			s1.close();
			ss.close();
		
	}
}
